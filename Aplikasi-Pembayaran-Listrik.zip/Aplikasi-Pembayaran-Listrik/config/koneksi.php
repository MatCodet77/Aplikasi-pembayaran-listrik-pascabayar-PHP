<?php  
	($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost", "root", ""));
	mysqli_select_db($GLOBALS["___mysqli_ston"], "pembayaran_listrik");
?>